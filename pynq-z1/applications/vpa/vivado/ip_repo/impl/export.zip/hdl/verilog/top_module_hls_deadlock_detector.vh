
    wire dl_reset;
    wire dl_clock;
    assign dl_reset = ap_rst_n;
    assign dl_clock = ap_clk;
    wire [0:0] proc_0_data_FIFO_blk;
    wire [0:0] proc_0_data_PIPO_blk;
    wire [0:0] proc_0_start_FIFO_blk;
    wire [0:0] proc_0_TLF_FIFO_blk;
    wire [0:0] proc_0_input_sync_blk;
    wire [0:0] proc_0_output_sync_blk;
    wire [0:0] proc_dep_vld_vec_0;
    reg [0:0] proc_dep_vld_vec_0_reg;
    wire [0:0] in_chan_dep_vld_vec_0;
    wire [7:0] in_chan_dep_data_vec_0;
    wire [0:0] token_in_vec_0;
    wire [0:0] out_chan_dep_vld_vec_0;
    wire [7:0] out_chan_dep_data_0;
    wire [0:0] token_out_vec_0;
    wire dl_detect_out_0;
    wire dep_chan_vld_1_0;
    wire [7:0] dep_chan_data_1_0;
    wire token_1_0;
    wire [1:0] proc_1_data_FIFO_blk;
    wire [1:0] proc_1_data_PIPO_blk;
    wire [1:0] proc_1_start_FIFO_blk;
    wire [1:0] proc_1_TLF_FIFO_blk;
    wire [1:0] proc_1_input_sync_blk;
    wire [1:0] proc_1_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_1;
    reg [1:0] proc_dep_vld_vec_1_reg;
    wire [1:0] in_chan_dep_vld_vec_1;
    wire [15:0] in_chan_dep_data_vec_1;
    wire [1:0] token_in_vec_1;
    wire [1:0] out_chan_dep_vld_vec_1;
    wire [7:0] out_chan_dep_data_1;
    wire [1:0] token_out_vec_1;
    wire dl_detect_out_1;
    wire dep_chan_vld_0_1;
    wire [7:0] dep_chan_data_0_1;
    wire token_0_1;
    wire dep_chan_vld_2_1;
    wire [7:0] dep_chan_data_2_1;
    wire token_2_1;
    wire [1:0] proc_2_data_FIFO_blk;
    wire [1:0] proc_2_data_PIPO_blk;
    wire [1:0] proc_2_start_FIFO_blk;
    wire [1:0] proc_2_TLF_FIFO_blk;
    wire [1:0] proc_2_input_sync_blk;
    wire [1:0] proc_2_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_2;
    reg [1:0] proc_dep_vld_vec_2_reg;
    wire [1:0] in_chan_dep_vld_vec_2;
    wire [15:0] in_chan_dep_data_vec_2;
    wire [1:0] token_in_vec_2;
    wire [1:0] out_chan_dep_vld_vec_2;
    wire [7:0] out_chan_dep_data_2;
    wire [1:0] token_out_vec_2;
    wire dl_detect_out_2;
    wire dep_chan_vld_1_2;
    wire [7:0] dep_chan_data_1_2;
    wire token_1_2;
    wire dep_chan_vld_3_2;
    wire [7:0] dep_chan_data_3_2;
    wire token_3_2;
    wire [2:0] proc_3_data_FIFO_blk;
    wire [2:0] proc_3_data_PIPO_blk;
    wire [2:0] proc_3_start_FIFO_blk;
    wire [2:0] proc_3_TLF_FIFO_blk;
    wire [2:0] proc_3_input_sync_blk;
    wire [2:0] proc_3_output_sync_blk;
    wire [2:0] proc_dep_vld_vec_3;
    reg [2:0] proc_dep_vld_vec_3_reg;
    wire [2:0] in_chan_dep_vld_vec_3;
    wire [23:0] in_chan_dep_data_vec_3;
    wire [2:0] token_in_vec_3;
    wire [2:0] out_chan_dep_vld_vec_3;
    wire [7:0] out_chan_dep_data_3;
    wire [2:0] token_out_vec_3;
    wire dl_detect_out_3;
    wire dep_chan_vld_2_3;
    wire [7:0] dep_chan_data_2_3;
    wire token_2_3;
    wire dep_chan_vld_4_3;
    wire [7:0] dep_chan_data_4_3;
    wire token_4_3;
    wire dep_chan_vld_5_3;
    wire [7:0] dep_chan_data_5_3;
    wire token_5_3;
    wire [1:0] proc_4_data_FIFO_blk;
    wire [1:0] proc_4_data_PIPO_blk;
    wire [1:0] proc_4_start_FIFO_blk;
    wire [1:0] proc_4_TLF_FIFO_blk;
    wire [1:0] proc_4_input_sync_blk;
    wire [1:0] proc_4_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_4;
    reg [1:0] proc_dep_vld_vec_4_reg;
    wire [1:0] in_chan_dep_vld_vec_4;
    wire [15:0] in_chan_dep_data_vec_4;
    wire [1:0] token_in_vec_4;
    wire [1:0] out_chan_dep_vld_vec_4;
    wire [7:0] out_chan_dep_data_4;
    wire [1:0] token_out_vec_4;
    wire dl_detect_out_4;
    wire dep_chan_vld_3_4;
    wire [7:0] dep_chan_data_3_4;
    wire token_3_4;
    wire dep_chan_vld_6_4;
    wire [7:0] dep_chan_data_6_4;
    wire token_6_4;
    wire [1:0] proc_5_data_FIFO_blk;
    wire [1:0] proc_5_data_PIPO_blk;
    wire [1:0] proc_5_start_FIFO_blk;
    wire [1:0] proc_5_TLF_FIFO_blk;
    wire [1:0] proc_5_input_sync_blk;
    wire [1:0] proc_5_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_5;
    reg [1:0] proc_dep_vld_vec_5_reg;
    wire [1:0] in_chan_dep_vld_vec_5;
    wire [15:0] in_chan_dep_data_vec_5;
    wire [1:0] token_in_vec_5;
    wire [1:0] out_chan_dep_vld_vec_5;
    wire [7:0] out_chan_dep_data_5;
    wire [1:0] token_out_vec_5;
    wire dl_detect_out_5;
    wire dep_chan_vld_3_5;
    wire [7:0] dep_chan_data_3_5;
    wire token_3_5;
    wire dep_chan_vld_6_5;
    wire [7:0] dep_chan_data_6_5;
    wire token_6_5;
    wire [2:0] proc_6_data_FIFO_blk;
    wire [2:0] proc_6_data_PIPO_blk;
    wire [2:0] proc_6_start_FIFO_blk;
    wire [2:0] proc_6_TLF_FIFO_blk;
    wire [2:0] proc_6_input_sync_blk;
    wire [2:0] proc_6_output_sync_blk;
    wire [2:0] proc_dep_vld_vec_6;
    reg [2:0] proc_dep_vld_vec_6_reg;
    wire [2:0] in_chan_dep_vld_vec_6;
    wire [23:0] in_chan_dep_data_vec_6;
    wire [2:0] token_in_vec_6;
    wire [2:0] out_chan_dep_vld_vec_6;
    wire [7:0] out_chan_dep_data_6;
    wire [2:0] token_out_vec_6;
    wire dl_detect_out_6;
    wire dep_chan_vld_4_6;
    wire [7:0] dep_chan_data_4_6;
    wire token_4_6;
    wire dep_chan_vld_5_6;
    wire [7:0] dep_chan_data_5_6;
    wire token_5_6;
    wire dep_chan_vld_7_6;
    wire [7:0] dep_chan_data_7_6;
    wire token_7_6;
    wire [0:0] proc_7_data_FIFO_blk;
    wire [0:0] proc_7_data_PIPO_blk;
    wire [0:0] proc_7_start_FIFO_blk;
    wire [0:0] proc_7_TLF_FIFO_blk;
    wire [0:0] proc_7_input_sync_blk;
    wire [0:0] proc_7_output_sync_blk;
    wire [0:0] proc_dep_vld_vec_7;
    reg [0:0] proc_dep_vld_vec_7_reg;
    wire [0:0] in_chan_dep_vld_vec_7;
    wire [7:0] in_chan_dep_data_vec_7;
    wire [0:0] token_in_vec_7;
    wire [0:0] out_chan_dep_vld_vec_7;
    wire [7:0] out_chan_dep_data_7;
    wire [0:0] token_out_vec_7;
    wire dl_detect_out_7;
    wire dep_chan_vld_6_7;
    wire [7:0] dep_chan_data_6_7;
    wire token_6_7;
    wire [7:0] dl_in_vec;
    wire dl_detect_out;
    wire token_clear;
    reg [7:0] origin;

    reg ap_done_reg_0;// for module grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_0 <= 'b0;
        end
        else begin
            ap_done_reg_0 <= grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_continue;
        end
    end

    reg ap_done_reg_1;// for module grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_1 <= 'b0;
        end
        else begin
            ap_done_reg_1 <= grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_done & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_continue;
        end
    end

    reg ap_done_reg_2;// for module grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_2 <= 'b0;
        end
        else begin
            ap_done_reg_2 <= grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_continue;
        end
    end

    reg ap_done_reg_3;// for module grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_3 <= 'b0;
        end
        else begin
            ap_done_reg_3 <= grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_done & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_continue;
        end
    end

    reg ap_done_reg_4;// for module grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_4 <= 'b0;
        end
        else begin
            ap_done_reg_4 <= grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_continue;
        end
    end

    reg ap_done_reg_5;// for module grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_5 <= 'b0;
        end
        else begin
            ap_done_reg_5 <= grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0.ap_done & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0.ap_continue;
        end
    end

    reg ap_done_reg_6;// for module grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_6 <= 'b0;
        end
        else begin
            ap_done_reg_6 <= grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_done & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_continue;
        end
    end

    reg ap_done_reg_7;// for module grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.hough_space_size_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_7 <= 'b0;
        end
        else begin
            ap_done_reg_7 <= grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.hough_space_size_U0.ap_done & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.hough_space_size_U0.ap_continue;
        end
    end

    // Process: grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0
    top_module_hls_deadlock_detect_unit #(8, 0, 1, 1) top_module_hls_deadlock_detect_unit_0 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_0),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_0),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_0),
        .token_in_vec(token_in_vec_0),
        .dl_detect_in(dl_detect_out),
        .origin(origin[0]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_0),
        .out_chan_dep_data(out_chan_dep_data_0),
        .token_out_vec(token_out_vec_0),
        .dl_detect_out(dl_in_vec[0]));

    assign proc_0_data_FIFO_blk[0] = 1'b0;
    assign proc_0_data_PIPO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ap_done_reg_0 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ap_done_reg_0 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ap_done_reg_0 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ap_done_reg_0 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_3_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ap_done_reg_0 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ap_done_reg_0 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ap_done_reg_0 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ap_done_reg_0 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_3_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ap_done_reg_0 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ap_done_reg_0 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ap_done_reg_0 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff1_U0.ap_done & ap_done_reg_0 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_3_U.t_read);
    assign proc_0_start_FIFO_blk[0] = 1'b0;
    assign proc_0_TLF_FIFO_blk[0] = 1'b0;
    assign proc_0_input_sync_blk[0] = 1'b0;
    assign proc_0_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_0[0] = dl_detect_out ? proc_dep_vld_vec_0_reg[0] : (proc_0_data_FIFO_blk[0] | proc_0_data_PIPO_blk[0] | proc_0_start_FIFO_blk[0] | proc_0_TLF_FIFO_blk[0] | proc_0_input_sync_blk[0] | proc_0_output_sync_blk[0]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_0_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_0_reg <= proc_dep_vld_vec_0;
        end
    end
    assign in_chan_dep_vld_vec_0[0] = dep_chan_vld_1_0;
    assign in_chan_dep_data_vec_0[7 : 0] = dep_chan_data_1_0;
    assign token_in_vec_0[0] = token_1_0;
    assign dep_chan_vld_0_1 = out_chan_dep_vld_vec_0[0];
    assign dep_chan_data_0_1 = out_chan_dep_data_0;
    assign token_0_1 = token_out_vec_0[0];

    // Process: grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0
    top_module_hls_deadlock_detect_unit #(8, 1, 2, 2) top_module_hls_deadlock_detect_unit_1 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_1),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_1),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_1),
        .token_in_vec(token_in_vec_1),
        .dl_detect_in(dl_detect_out),
        .origin(origin[1]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_1),
        .out_chan_dep_data(out_chan_dep_data_1),
        .token_out_vec(token_out_vec_1),
        .dl_detect_out(dl_in_vec[1]));

    assign proc_1_data_FIFO_blk[0] = 1'b0;
    assign proc_1_data_PIPO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in0_3_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in1_3_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_in2_3_U.i_write);
    assign proc_1_start_FIFO_blk[0] = 1'b0;
    assign proc_1_TLF_FIFO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c6_channel_U.if_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c6_channel_U.if_write);
    assign proc_1_input_sync_blk[0] = 1'b0;
    assign proc_1_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_1[0] = dl_detect_out ? proc_dep_vld_vec_1_reg[0] : (proc_1_data_FIFO_blk[0] | proc_1_data_PIPO_blk[0] | proc_1_start_FIFO_blk[0] | proc_1_TLF_FIFO_blk[0] | proc_1_input_sync_blk[0] | proc_1_output_sync_blk[0]);
    assign proc_1_data_FIFO_blk[1] = 1'b0;
    assign proc_1_data_PIPO_blk[1] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_done & ap_done_reg_1 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_done & ap_done_reg_1 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_done & ap_done_reg_1 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gaussian_U0.ap_done & ap_done_reg_1 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_3_U.t_read);
    assign proc_1_start_FIFO_blk[1] = 1'b0;
    assign proc_1_TLF_FIFO_blk[1] = 1'b0;
    assign proc_1_input_sync_blk[1] = 1'b0;
    assign proc_1_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_1[1] = dl_detect_out ? proc_dep_vld_vec_1_reg[1] : (proc_1_data_FIFO_blk[1] | proc_1_data_PIPO_blk[1] | proc_1_start_FIFO_blk[1] | proc_1_TLF_FIFO_blk[1] | proc_1_input_sync_blk[1] | proc_1_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_1_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_1_reg <= proc_dep_vld_vec_1;
        end
    end
    assign in_chan_dep_vld_vec_1[0] = dep_chan_vld_0_1;
    assign in_chan_dep_data_vec_1[7 : 0] = dep_chan_data_0_1;
    assign token_in_vec_1[0] = token_0_1;
    assign in_chan_dep_vld_vec_1[1] = dep_chan_vld_2_1;
    assign in_chan_dep_data_vec_1[15 : 8] = dep_chan_data_2_1;
    assign token_in_vec_1[1] = token_2_1;
    assign dep_chan_vld_1_0 = out_chan_dep_vld_vec_1[0];
    assign dep_chan_data_1_0 = out_chan_dep_data_1;
    assign token_1_0 = token_out_vec_1[0];
    assign dep_chan_vld_1_2 = out_chan_dep_vld_vec_1[1];
    assign dep_chan_data_1_2 = out_chan_dep_data_1;
    assign token_1_2 = token_out_vec_1[1];

    // Process: grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0
    top_module_hls_deadlock_detect_unit #(8, 2, 2, 2) top_module_hls_deadlock_detect_unit_2 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_2),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_2),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_2),
        .token_in_vec(token_in_vec_2),
        .dl_detect_in(dl_detect_out),
        .origin(origin[2]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_2),
        .out_chan_dep_data(out_chan_dep_data_2),
        .token_out_vec(token_out_vec_2),
        .dl_detect_out(dl_in_vec[2]));

    assign proc_2_data_FIFO_blk[0] = 1'b0;
    assign proc_2_data_PIPO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga_3_U.i_write);
    assign proc_2_start_FIFO_blk[0] = 1'b0;
    assign proc_2_TLF_FIFO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c5_channel_U.if_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c5_channel_U.if_write);
    assign proc_2_input_sync_blk[0] = 1'b0;
    assign proc_2_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_2[0] = dl_detect_out ? proc_dep_vld_vec_2_reg[0] : (proc_2_data_FIFO_blk[0] | proc_2_data_PIPO_blk[0] | proc_2_start_FIFO_blk[0] | proc_2_TLF_FIFO_blk[0] | proc_2_input_sync_blk[0] | proc_2_output_sync_blk[0]);
    assign proc_2_data_FIFO_blk[1] = 1'b0;
    assign proc_2_data_PIPO_blk[1] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ap_done_reg_2 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ap_done_reg_2 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ap_done_reg_2 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ap_done_reg_2 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ap_done_reg_2 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ap_done_reg_2 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ap_done_reg_2 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ap_done_reg_2 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_3_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ap_done_reg_2 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ap_done_reg_2 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_3_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ap_done_reg_2 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff2_U0.ap_done & ap_done_reg_2 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_3_U.t_read);
    assign proc_2_start_FIFO_blk[1] = 1'b0;
    assign proc_2_TLF_FIFO_blk[1] = 1'b0;
    assign proc_2_input_sync_blk[1] = 1'b0;
    assign proc_2_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_2[1] = dl_detect_out ? proc_dep_vld_vec_2_reg[1] : (proc_2_data_FIFO_blk[1] | proc_2_data_PIPO_blk[1] | proc_2_start_FIFO_blk[1] | proc_2_TLF_FIFO_blk[1] | proc_2_input_sync_blk[1] | proc_2_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_2_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_2_reg <= proc_dep_vld_vec_2;
        end
    end
    assign in_chan_dep_vld_vec_2[0] = dep_chan_vld_1_2;
    assign in_chan_dep_data_vec_2[7 : 0] = dep_chan_data_1_2;
    assign token_in_vec_2[0] = token_1_2;
    assign in_chan_dep_vld_vec_2[1] = dep_chan_vld_3_2;
    assign in_chan_dep_data_vec_2[15 : 8] = dep_chan_data_3_2;
    assign token_in_vec_2[1] = token_3_2;
    assign dep_chan_vld_2_1 = out_chan_dep_vld_vec_2[0];
    assign dep_chan_data_2_1 = out_chan_dep_data_2;
    assign token_2_1 = token_out_vec_2[0];
    assign dep_chan_vld_2_3 = out_chan_dep_vld_vec_2[1];
    assign dep_chan_data_2_3 = out_chan_dep_data_2;
    assign token_2_3 = token_out_vec_2[1];

    // Process: grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0
    top_module_hls_deadlock_detect_unit #(8, 3, 3, 3) top_module_hls_deadlock_detect_unit_3 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_3),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_3),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_3),
        .token_in_vec(token_in_vec_3),
        .dl_detect_in(dl_detect_out),
        .origin(origin[3]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_3),
        .out_chan_dep_data(out_chan_dep_data_3),
        .token_out_vec(token_out_vec_3),
        .dl_detect_out(dl_in_vec[3]));

    assign proc_3_data_FIFO_blk[0] = 1'b0;
    assign proc_3_data_PIPO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga0_3_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga1_3_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ga2_3_U.i_write);
    assign proc_3_start_FIFO_blk[0] = 1'b0;
    assign proc_3_TLF_FIFO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c4_channel_U.if_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c4_channel_U.if_write);
    assign proc_3_input_sync_blk[0] = 1'b0;
    assign proc_3_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_3[0] = dl_detect_out ? proc_dep_vld_vec_3_reg[0] : (proc_3_data_FIFO_blk[0] | proc_3_data_PIPO_blk[0] | proc_3_start_FIFO_blk[0] | proc_3_TLF_FIFO_blk[0] | proc_3_input_sync_blk[0] | proc_3_output_sync_blk[0]);
    assign proc_3_data_FIFO_blk[1] = 1'b0;
    assign proc_3_data_PIPO_blk[1] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_done & ap_done_reg_3 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_done & ap_done_reg_3 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_done & ap_done_reg_3 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_done & ap_done_reg_3 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_3_U.t_read);
    assign proc_3_start_FIFO_blk[1] = 1'b0;
    assign proc_3_TLF_FIFO_blk[1] = 1'b0;
    assign proc_3_input_sync_blk[1] = 1'b0;
    assign proc_3_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_3[1] = dl_detect_out ? proc_dep_vld_vec_3_reg[1] : (proc_3_data_FIFO_blk[1] | proc_3_data_PIPO_blk[1] | proc_3_start_FIFO_blk[1] | proc_3_TLF_FIFO_blk[1] | proc_3_input_sync_blk[1] | proc_3_output_sync_blk[1]);
    assign proc_3_data_FIFO_blk[2] = 1'b0;
    assign proc_3_data_PIPO_blk[2] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_done & ap_done_reg_3 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_done & ap_done_reg_3 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_done & ap_done_reg_3 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.gradient_U0.ap_done & ap_done_reg_3 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_3_U.t_read);
    assign proc_3_start_FIFO_blk[2] = 1'b0;
    assign proc_3_TLF_FIFO_blk[2] = 1'b0;
    assign proc_3_input_sync_blk[2] = 1'b0;
    assign proc_3_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_3[2] = dl_detect_out ? proc_dep_vld_vec_3_reg[2] : (proc_3_data_FIFO_blk[2] | proc_3_data_PIPO_blk[2] | proc_3_start_FIFO_blk[2] | proc_3_TLF_FIFO_blk[2] | proc_3_input_sync_blk[2] | proc_3_output_sync_blk[2]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_3_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_3_reg <= proc_dep_vld_vec_3;
        end
    end
    assign in_chan_dep_vld_vec_3[0] = dep_chan_vld_2_3;
    assign in_chan_dep_data_vec_3[7 : 0] = dep_chan_data_2_3;
    assign token_in_vec_3[0] = token_2_3;
    assign in_chan_dep_vld_vec_3[1] = dep_chan_vld_4_3;
    assign in_chan_dep_data_vec_3[15 : 8] = dep_chan_data_4_3;
    assign token_in_vec_3[1] = token_4_3;
    assign in_chan_dep_vld_vec_3[2] = dep_chan_vld_5_3;
    assign in_chan_dep_data_vec_3[23 : 16] = dep_chan_data_5_3;
    assign token_in_vec_3[2] = token_5_3;
    assign dep_chan_vld_3_2 = out_chan_dep_vld_vec_3[0];
    assign dep_chan_data_3_2 = out_chan_dep_data_3;
    assign token_3_2 = token_out_vec_3[0];
    assign dep_chan_vld_3_5 = out_chan_dep_vld_vec_3[1];
    assign dep_chan_data_3_5 = out_chan_dep_data_3;
    assign token_3_5 = token_out_vec_3[1];
    assign dep_chan_vld_3_4 = out_chan_dep_vld_vec_3[2];
    assign dep_chan_data_3_4 = out_chan_dep_data_3;
    assign token_3_4 = token_out_vec_3[2];

    // Process: grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0
    top_module_hls_deadlock_detect_unit #(8, 4, 2, 2) top_module_hls_deadlock_detect_unit_4 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_4),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_4),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_4),
        .token_in_vec(token_in_vec_4),
        .dl_detect_in(dl_detect_out),
        .origin(origin[4]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_4),
        .out_chan_dep_data(out_chan_dep_data_4),
        .token_out_vec(token_out_vec_4),
        .dl_detect_out(dl_in_vec[4]));

    assign proc_4_data_FIFO_blk[0] = 1'b0;
    assign proc_4_data_PIPO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeMagnitudeC_3_U.i_write);
    assign proc_4_start_FIFO_blk[0] = 1'b0;
    assign proc_4_TLF_FIFO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c3_channel_U.if_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c3_channel_U.if_write);
    assign proc_4_input_sync_blk[0] = 1'b0;
    assign proc_4_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_4[0] = dl_detect_out ? proc_dep_vld_vec_4_reg[0] : (proc_4_data_FIFO_blk[0] | proc_4_data_PIPO_blk[0] | proc_4_start_FIFO_blk[0] | proc_4_TLF_FIFO_blk[0] | proc_4_input_sync_blk[0] | proc_4_output_sync_blk[0]);
    assign proc_4_data_FIFO_blk[1] = 1'b0;
    assign proc_4_data_PIPO_blk[1] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_3_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_7_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_7_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_3_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_3_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_magn_U0.ap_done & ap_done_reg_4 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_3_U.t_read);
    assign proc_4_start_FIFO_blk[1] = 1'b0;
    assign proc_4_TLF_FIFO_blk[1] = 1'b0;
    assign proc_4_input_sync_blk[1] = 1'b0;
    assign proc_4_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_4[1] = dl_detect_out ? proc_dep_vld_vec_4_reg[1] : (proc_4_data_FIFO_blk[1] | proc_4_data_PIPO_blk[1] | proc_4_start_FIFO_blk[1] | proc_4_TLF_FIFO_blk[1] | proc_4_input_sync_blk[1] | proc_4_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_4_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_4_reg <= proc_dep_vld_vec_4;
        end
    end
    assign in_chan_dep_vld_vec_4[0] = dep_chan_vld_3_4;
    assign in_chan_dep_data_vec_4[7 : 0] = dep_chan_data_3_4;
    assign token_in_vec_4[0] = token_3_4;
    assign in_chan_dep_vld_vec_4[1] = dep_chan_vld_6_4;
    assign in_chan_dep_data_vec_4[15 : 8] = dep_chan_data_6_4;
    assign token_in_vec_4[1] = token_6_4;
    assign dep_chan_vld_4_3 = out_chan_dep_vld_vec_4[0];
    assign dep_chan_data_4_3 = out_chan_dep_data_4;
    assign token_4_3 = token_out_vec_4[0];
    assign dep_chan_vld_4_6 = out_chan_dep_vld_vec_4[1];
    assign dep_chan_data_4_6 = out_chan_dep_data_4;
    assign token_4_6 = token_out_vec_4[1];

    // Process: grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0
    top_module_hls_deadlock_detect_unit #(8, 5, 2, 2) top_module_hls_deadlock_detect_unit_5 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_5),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_5),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_5),
        .token_in_vec(token_in_vec_5),
        .dl_detect_in(dl_detect_out),
        .origin(origin[5]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_5),
        .out_chan_dep_data(out_chan_dep_data_5),
        .token_out_vec(token_out_vec_5),
        .dl_detect_out(dl_in_vec[5]));

    assign proc_5_data_FIFO_blk[0] = 1'b0;
    assign proc_5_data_PIPO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edgeDirection_3_U.i_write);
    assign proc_5_start_FIFO_blk[0] = 1'b0;
    assign proc_5_TLF_FIFO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c2_channel_U.if_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c2_channel_U.if_write);
    assign proc_5_input_sync_blk[0] = 1'b0;
    assign proc_5_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_5[0] = dl_detect_out ? proc_dep_vld_vec_5_reg[0] : (proc_5_data_FIFO_blk[0] | proc_5_data_PIPO_blk[0] | proc_5_start_FIFO_blk[0] | proc_5_TLF_FIFO_blk[0] | proc_5_input_sync_blk[0] | proc_5_output_sync_blk[0]);
    assign proc_5_data_FIFO_blk[1] = 1'b0;
    assign proc_5_data_PIPO_blk[1] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0.ap_done & ap_done_reg_5 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0.ap_done & ap_done_reg_5 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0.ap_done & ap_done_reg_5 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.line_buff3_dir_U0.ap_done & ap_done_reg_5 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_3_U.t_read);
    assign proc_5_start_FIFO_blk[1] = 1'b0;
    assign proc_5_TLF_FIFO_blk[1] = 1'b0;
    assign proc_5_input_sync_blk[1] = 1'b0;
    assign proc_5_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_5[1] = dl_detect_out ? proc_dep_vld_vec_5_reg[1] : (proc_5_data_FIFO_blk[1] | proc_5_data_PIPO_blk[1] | proc_5_start_FIFO_blk[1] | proc_5_TLF_FIFO_blk[1] | proc_5_input_sync_blk[1] | proc_5_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_5_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_5_reg <= proc_dep_vld_vec_5;
        end
    end
    assign in_chan_dep_vld_vec_5[0] = dep_chan_vld_3_5;
    assign in_chan_dep_data_vec_5[7 : 0] = dep_chan_data_3_5;
    assign token_in_vec_5[0] = token_3_5;
    assign in_chan_dep_vld_vec_5[1] = dep_chan_vld_6_5;
    assign in_chan_dep_data_vec_5[15 : 8] = dep_chan_data_6_5;
    assign token_in_vec_5[1] = token_6_5;
    assign dep_chan_vld_5_3 = out_chan_dep_vld_vec_5[0];
    assign dep_chan_data_5_3 = out_chan_dep_data_5;
    assign token_5_3 = token_out_vec_5[0];
    assign dep_chan_vld_5_6 = out_chan_dep_vld_vec_5[1];
    assign dep_chan_data_5_6 = out_chan_dep_data_5;
    assign token_5_6 = token_out_vec_5[1];

    // Process: grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0
    top_module_hls_deadlock_detect_unit #(8, 6, 3, 3) top_module_hls_deadlock_detect_unit_6 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_6),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_6),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_6),
        .token_in_vec(token_in_vec_6),
        .dl_detect_in(dl_detect_out),
        .origin(origin[6]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_6),
        .out_chan_dep_data(out_chan_dep_data_6),
        .token_out_vec(token_out_vec_6),
        .dl_detect_out(dl_in_vec[6]));

    assign proc_6_data_FIFO_blk[0] = 1'b0;
    assign proc_6_data_PIPO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_3_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_dir_2_U.i_write);
    assign proc_6_start_FIFO_blk[0] = 1'b0;
    assign proc_6_TLF_FIFO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c1_channel_U.if_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c1_channel_U.if_write);
    assign proc_6_input_sync_blk[0] = 1'b0;
    assign proc_6_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_6[0] = dl_detect_out ? proc_dep_vld_vec_6_reg[0] : (proc_6_data_FIFO_blk[0] | proc_6_data_PIPO_blk[0] | proc_6_start_FIFO_blk[0] | proc_6_TLF_FIFO_blk[0] | proc_6_input_sync_blk[0] | proc_6_output_sync_blk[0]);
    assign proc_6_data_FIFO_blk[1] = 1'b0;
    assign proc_6_data_PIPO_blk[1] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_7_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_7_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_3_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_3_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_3_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma0_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma2_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.img_ma1_1_3_U.i_write);
    assign proc_6_start_FIFO_blk[1] = 1'b0;
    assign proc_6_TLF_FIFO_blk[1] = 1'b0;
    assign proc_6_input_sync_blk[1] = 1'b0;
    assign proc_6_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_6[1] = dl_detect_out ? proc_dep_vld_vec_6_reg[1] : (proc_6_data_FIFO_blk[1] | proc_6_data_PIPO_blk[1] | proc_6_start_FIFO_blk[1] | proc_6_TLF_FIFO_blk[1] | proc_6_input_sync_blk[1] | proc_6_output_sync_blk[1]);
    assign proc_6_data_FIFO_blk[2] = 1'b0;
    assign proc_6_data_PIPO_blk[2] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_0_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_done & ap_done_reg_6 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_0_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_2_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_done & ap_done_reg_6 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_2_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_1_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_done & ap_done_reg_6 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_1_U.t_read) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_3_U.i_full_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.nMS_Hys_U0.ap_done & ap_done_reg_6 & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_3_U.t_read);
    assign proc_6_start_FIFO_blk[2] = 1'b0;
    assign proc_6_TLF_FIFO_blk[2] = 1'b0;
    assign proc_6_input_sync_blk[2] = 1'b0;
    assign proc_6_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_6[2] = dl_detect_out ? proc_dep_vld_vec_6_reg[2] : (proc_6_data_FIFO_blk[2] | proc_6_data_PIPO_blk[2] | proc_6_start_FIFO_blk[2] | proc_6_TLF_FIFO_blk[2] | proc_6_input_sync_blk[2] | proc_6_output_sync_blk[2]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_6_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_6_reg <= proc_dep_vld_vec_6;
        end
    end
    assign in_chan_dep_vld_vec_6[0] = dep_chan_vld_4_6;
    assign in_chan_dep_data_vec_6[7 : 0] = dep_chan_data_4_6;
    assign token_in_vec_6[0] = token_4_6;
    assign in_chan_dep_vld_vec_6[1] = dep_chan_vld_5_6;
    assign in_chan_dep_data_vec_6[15 : 8] = dep_chan_data_5_6;
    assign token_in_vec_6[1] = token_5_6;
    assign in_chan_dep_vld_vec_6[2] = dep_chan_vld_7_6;
    assign in_chan_dep_data_vec_6[23 : 16] = dep_chan_data_7_6;
    assign token_in_vec_6[2] = token_7_6;
    assign dep_chan_vld_6_5 = out_chan_dep_vld_vec_6[0];
    assign dep_chan_data_6_5 = out_chan_dep_data_6;
    assign token_6_5 = token_out_vec_6[0];
    assign dep_chan_vld_6_4 = out_chan_dep_vld_vec_6[1];
    assign dep_chan_data_6_4 = out_chan_dep_data_6;
    assign token_6_4 = token_out_vec_6[1];
    assign dep_chan_vld_6_7 = out_chan_dep_vld_vec_6[2];
    assign dep_chan_data_6_7 = out_chan_dep_data_6;
    assign token_6_7 = token_out_vec_6[2];

    // Process: grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.hough_space_size_U0
    top_module_hls_deadlock_detect_unit #(8, 7, 1, 1) top_module_hls_deadlock_detect_unit_7 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_7),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_7),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_7),
        .token_in_vec(token_in_vec_7),
        .dl_detect_in(dl_detect_out),
        .origin(origin[7]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_7),
        .out_chan_dep_data(out_chan_dep_data_7),
        .token_out_vec(token_out_vec_7),
        .dl_detect_out(dl_in_vec[7]));

    assign proc_7_data_FIFO_blk[0] = 1'b0;
    assign proc_7_data_PIPO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_0_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.hough_space_size_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_0_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_1_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.hough_space_size_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_1_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_2_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.hough_space_size_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_2_U.i_write) | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_3_U.t_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.hough_space_size_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.edg_img_3_U.i_write);
    assign proc_7_start_FIFO_blk[0] = 1'b0;
    assign proc_7_TLF_FIFO_blk[0] = 1'b0 | (~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c_channel_U.if_empty_n & grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.hough_space_size_U0.ap_idle & ~grp_dataflow_parent_loop_proc_fu_2615.dataflow_in_loop_VITIS_LOOP_190_1_U0.y_0_c_channel_U.if_write);
    assign proc_7_input_sync_blk[0] = 1'b0;
    assign proc_7_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_7[0] = dl_detect_out ? proc_dep_vld_vec_7_reg[0] : (proc_7_data_FIFO_blk[0] | proc_7_data_PIPO_blk[0] | proc_7_start_FIFO_blk[0] | proc_7_TLF_FIFO_blk[0] | proc_7_input_sync_blk[0] | proc_7_output_sync_blk[0]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_7_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_7_reg <= proc_dep_vld_vec_7;
        end
    end
    assign in_chan_dep_vld_vec_7[0] = dep_chan_vld_6_7;
    assign in_chan_dep_data_vec_7[7 : 0] = dep_chan_data_6_7;
    assign token_in_vec_7[0] = token_6_7;
    assign dep_chan_vld_7_6 = out_chan_dep_vld_vec_7[0];
    assign dep_chan_data_7_6 = out_chan_dep_data_7;
    assign token_7_6 = token_out_vec_7[0];


`include "top_module_hls_deadlock_report_unit.vh"
